template <class T>
class Search_tree : public Binary_tree<T> {
public:
	Error_code insert(const T &new_data);
	Error_code remove(const T &old_data);
	Error_code tree_search(T &target) const;
protected:

	// Auxiliary functions called by the public functions
	Error_code search_and_insert(Binary_node<T>* &sub_root, const T &new_data);
	Error_code search_and_delete(Binary_node<T>* &sub_root, const T &target);

};


template <class T>
Error_code Search_tree<T>::insert(const T &new_data)
{
	return search_and_insert(this->root, new_data);
}


template <class T>
Error_code Search_tree<T>::search_and_insert(
	Binary_node<T> *&sub_root, const T &new_data)
{
	if (sub_root == NULL)//check if sub_root is null if so
	{
		sub_root = new Binary_node<T>(new_data);//create a new sub root passing new_data as argument
		return success;//and return success value
	}
	else if (new_data < sub_root->data)//otherwise check if new_data is less than current data of sub_root if so
		return search_and_insert(sub_root->left, new_data);//insert the node to left side of sub_root
	else if (new_data > sub_root->data)//otherwise check if new_data is greatern than current data of sub_root if so
		return search_and_insert(sub_root->right, new_data);//insert the node to right side of sub_root
	else return duplicate_error;//otherwise simply return the duplicate_error message
}


template <class T>
Error_code Search_tree<T>::remove(const T &target)
/*
Post: If a T with a key matching that of target belongs to the
Search_tree, a code of success is returned, and the corresponding node is removed from the tree.  Otherwise, a code of not_present is returned.
Uses: Function search_and_delete
*/
{
	return search_and_delete(this->root, target);
}


template <class T>
Error_code Search_tree<T>::search_and_delete(
	Binary_node<T>* &sub_root, const T &target)
	/*
	Pre:  sub_root is either NULL or points to a subtree of the Search_tree.
	Post: If the key of target is not in the subtree, a code of not_present
	is returned.  Otherwise, a code of success is returned and the subtree
	node containing target has been removed in such a way that
	the properties of a binary search tree have been preserved.
	Uses: Functions search_and_delete recursively
	*/
{
	if (sub_root == NULL || sub_root->data == target)
	{
		if (sub_root == NULL)return not_present;
		Binary_node<T>* toDel = sub_root;
		if (sub_root->right == NULL)sub_root = sub_root->left;
		else if (sub_root->left == NULL)sub_root = sub_root->right;
		else
		{
			toDel = sub_root->left;
			Binary_node<T>* parent = sub_root;
			while (toDel->right != NULL)
			{
				parent = toDel;
				toDel = toDel->right;
			}
			sub_root->data = toDel->data;
			if (parent == sub_root)sub_root->left = toDel->left;
			else parent->right = toDel->left;
		}
		delete toDel;
		return success;
	}
	else if (target < sub_root->data)
		return search_and_delete(sub_root->left, target);
	else
		return search_and_delete(sub_root->right, target);
}